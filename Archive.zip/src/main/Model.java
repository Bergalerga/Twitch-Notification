package main;

/**
 * Created by berg on 18/07/15.
 */
public class Model {

}
